# ERA: Восхождение / ERA: Ascension

Нативная Android 3D Action RPG на **Godot 4.7.1** (GDScript, Mobile-рендерер с автоматическим откатом на OpenGL ES 3).
Пять исторических эпох, живой мир с автономными NPC, живые легенды, группировки, задания, боссы, разломы и
историческое наследие. Игра полностью офлайн: интернет и внешние нейросети не нужны.

> Версия 0.9.0 — первая полная сборка. Что сделано и что осталось, см. в [PROGRESS.md](PROGRESS.md) и [NEXT_STEPS.md](NEXT_STEPS.md).

## Готовые файлы

| Файл | Что это |
|---|---|
| `dist/ERA_Ascension.apk` | Release-сборка, arm64-v8a, ~34 МБ, подписана локально созданным release-ключом |
| `dist/ERA_Ascension-debug.apk` | Debug-сборка, arm64-v8a, ~36 МБ, подписана стандартным debug-ключом |
| `dist/ERA_Ascension_Source.zip` | Полный исходный проект Godot (тот же, что в репозитории) |
| [TEST_REPORT.md](TEST_REPORT.md) | Автотесты и проверки, скриншоты |
| [BUILD_REPORT.md](BUILD_REPORT.md) | Как собраны APK, проверка подписи и манифеста |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Архитектура подсистем |

## Установка на телефон

1. Скопируйте `ERA_Ascension.apk` на Android-устройство (Android 7.0 / API 24 и новее, процессор ARM64).
2. Разрешите установку из неизвестных источников для файлового менеджера или браузера.
3. Откройте APK и установите. Если раньше стояла сборка с другой подписью (например, debug), сначала удалите её.
4. Запускайте «ERA: Восхождение». Игра работает в горизонтальной ориентации.

Через ADB: `adb install -r dist/ERA_Ascension.apk`.

## Управление

**Сенсорное (мультитач):**
- Левая половина экрана — плавающий джойстик движения.
- **АТАКА** — основная атака. Удержание — автоатака с автоприцелом. Потяните палец от кнопки, чтобы целиться вручную (лук, огнестрел, магия).
- **БЛОК** — блок. Нажмите в момент удара врага, чтобы парировать (оглушает атакующего).
- **РЫВОК** — уклонение с неуязвимостью.
- Три кнопки умений — приёмы текущего оружия и заклинания. Назначаются в окне «Навыки».
- **!** — контекстное действие: подобрать, открыть, поговорить, войти в портал, пощадить врага.
- **ОРУЖ.** — смена оружия. Красная кнопка с цифрой — зелье. Кнопка спутника — его режим: за мной / атаковать / стоять.
- Вверху справа: меню, сумка, навыки, карта. Тап по мини-карте открывает большую карту.
- Кнопка «Назад» Android закрывает окна и открывает паузу.

**Клавиатура (для отладки на ПК):** WASD — движение, J или ЛКМ — атака, K или ПКМ — блок, Пробел — рывок, 1/2/3 — умения,
F/E — действие, Tab/R — смена оружия, H — зелье, I — инвентарь, O — навыки, M — карта, L — журнал, C — спутник, Esc — пауза.

## Режимы

- **Живой мир** — основной режим: открытый мир 2,56 × 2,56 км с потоковой загрузкой, поселения, фракции, задания, боссы, разломы, эпохи.
- **Арена** — компактная арена в духе Slither.io: старт слабым, сферы опыта, соперники-боты, волны врагов. В основной профиль переносится 50% мастерства.
- **Испытания** — 10 волн с чемпионами и боссом эпохи. Награды за 3-ю, 6-ю и 9-ю волны идут в инвентарь основного персонажа.
- **Хроноподземелья** — три зала разломов подряд. Добыча сохраняется только при успешном выходе.

## Сборка из исходников

```bash
# Godot 4.7.1 + шаблоны экспорта 4.7.1, JDK 17+, Android SDK (platform-tools + build-tools с apksigner)
tools/build_apk.sh both        # → builds/ERA_Ascension-debug.apk и builds/ERA_Ascension.apk
tools/check.sh                 # проверка компиляции всех скриптов
godot --headless --path . tests/logic_test.tscn        # 67 проверок игровых систем
godot --headless --path . tests/world_logic_test.tscn  # 122 проверки мира
```
Для публикации в магазине подпишите release-сборку своим ключом: задайте переменные
`ERA_RELEASE_KEYSTORE`, `ERA_RELEASE_ALIAS` и `ERA_RELEASE_PASSWORD` перед запуском `tools/build_apk.sh release`.
Подробности в [BUILD_REPORT.md](BUILD_REPORT.md).

## Структура

```
scripts/core       Game, Events, Settings, Profile, CharData, SpatialGrid
scripts/data       эпохи, фракции, враги, боссы, классы, навыки, школы магии, имена
scripts/items      ItemDB (предметы, редкость, проклятия, уникальные), Inventory, Loot, ItemDrop, сферы опыта, живое оружие
scripts/actors     Actor, Player, NPC, Monster, Boss, процедурные модели и анимации (HumanoidRig, CreatureRig, WeaponModels)
scripts/combat     Combat (урон, LOS), Projectile, Zone, Spells (20 заклинаний), Skills (приёмы оружия)
scripts/ai         BotBrain (utility AI + память), MonsterBrain, BossBrain, ChronoBrain
scripts/world      World (сцена игры), WorldGen, ChunkStreamer, Building, Destructible, Chest, Props, DayNight, Weather,
                   Poi (точки интереса), Dimension (разломы и арены), Dialogs, Stations, Fortress, GameModes, Spawner
scripts/sim        FactionSystem, LegendSystem, WorldSim (фоновая симуляция), WorldDirector (события)
scripts/quests     QuestSystem
scripts/history    Chronicle (единый журнал событий), Legacy (наследие эпох), Witness (Последний Свидетель)
scripts/save       SaveSystem (атомарная запись, .bak, версии)
scripts/ui         HUD, сенсорное управление, мини-карта, камера, тема, менеджер окон, 14 экранов, 3D-меню
assets             шрифты (OFL), синтезированные звуки и музыка, иконка
tools              сборка APK, проверка скриптов, генератор звука, генератор иконки
tests              автотесты и скриншот-тесты
```

## Лицензии ресурсов

Все модели, анимации, эффекты, интерфейс и иконка созданы процедурно в этом проекте. Звуки и музыку синтезирует
`tools/gen_audio.py`, они оригинальные. Шрифты: PT Sans, Philosopher, Ruslan Display (SIL Open Font License,
файлы `assets/fonts/OFL_*.txt`) и подмножество DejaVu для символов (`assets/fonts/LICENSE_DejaVu.txt`).
